//Новая программа

// console.log(2*(2+4));

//Новая программа
// let count = 2;
// let price = 50;
// alert(price*count);

//Новая программа
// const PI = 3.14;
// const R = 6371;

// let lenght = 2*PI*R

// console.log("Длина экватора:", lenght);

//Новая программа

// let counter = 2
// counter = 5

// console.log(counter);
//5 

//Новая программа

// let counter = 2
// counter = counter + 5;

// console.log(counter);
//5 

//Новая программа
// let counter = 1

// counter = counter + 1;
// counter = counter + 1;
// counter = counter + 1;
// counter = counter + 1;
//1
//2
//3
//4
//5
// console.log(counter);
//5

// инкремент
// let counter = 1;

// counter++ 
// counter++ 
// counter++ 
// counter++ 
// console.log(counter);

// декремент
// let counter = 1;

// counter++ 
// counter++ 
// counter-- 
// counter-- 
//1


//новая программа
//сначала вывод в консоль а потом прибавится 1 
// let counter = 1;

// console.log(counter++);

//новая программа
// console.log(counter);

// let counter = 1;

// console.log(++counter);
// console.log(++counter);


//новая программа
//тут сначала отняли 1 потом вывелось 1  а потом прибавили 

// let counter = 1;

// console.log(counter--);
// console.log(counter--);
// console.log(counter--);
// console.log(++counter);